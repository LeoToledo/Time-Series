#include "tad.h"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>

using namespace std;

//M�TODOS DA LISTA
void Lista::mostrar() //Implementa��o do m�todo mostrar
{
    cout << "\nImprimindo todos os elementos...\n";
    No* c = cabeca;
    if(vazia())
        cout << "A lista nao possui elementos!!\n";
    else
    {
        while(c) // percorre a lista
        {
            cout << c->obterValor() << endl;
            c = c->obterProx();
        }
        cout << endl;
    }
}

void Lista::inserir_elem(float v)
{
    No* novo_no = new No(v);
    if(vazia())
    {
        cabeca = novo_no;
        cauda = novo_no;
    }
    else
    {
        cauda->setProx(novo_no);
        cauda = novo_no;
    }
}

// retorna o tamanho da lista
int Lista::tamanho()
{
    if(vazia()) // se for vazia, ent� retorna 0
        return 0;
    No* c = cabeca;
    int tam = 0;

    // percorre a lista
    do
    {
        c = c->obterProx();
        tam++;
    }
    while(c);

    return tam;
}


void Lista::remover()
{
    if(!vazia())
    {
        // se houver s� 1 elemento
        if(cabeca->obterProx() == NULL)
            cabeca = NULL;
        else if(cabeca->obterProx()->obterProx() == NULL) // 2 elementos
            cabeca->setProx(NULL);
        else // > 2 elementos
        {
            No* ant_ant = cabeca;
            No* ant = cabeca->obterProx();
            No* corrente = cabeca->obterProx()->obterProx();
            while(corrente)
            {
                No* aux = ant;
                ant = corrente;
                ant_ant = aux;
                corrente = corrente->obterProx();
            }
            delete ant_ant->obterProx(); // libera mem�ria
            ant_ant->setProx(NULL); // seta o prox como NULL
            cauda = ant_ant; // atualiza a cauda
        }
    }
}

void Lista::liberar_memoria()  //libera mem�ria de todos os elementos da lista
{
    No *no = cabeca, *aux;
    while(no != 0)
    {
        aux = no;
        no = no->obterProx();
        free(aux);
    }
    cabeca = 0;
}
//FIM M�TODOS DA LISTA

//ALOCAR VALORES DA LISTA NUMA MATRIZ
void aloca_matriz(Elemento *m[][C], Lista *serie, int tam) //M � a matriz que guardar� as s�ries, "serie" � a lista com as s�ries a serem distribuidas e tam � a quantidade de s�ries
{
    //variaveis auxiliares
    int i, j, tipoAux;
    No *noAux = serie->getCabeca(); //N� auxiliar que ir� percorrer a lista

    for(i = 0; i < tam; i++)
    {
        for(j = 0; j < C; j++)
        {
            tipoAux = j; //guarda o tipo do elemento
            m[i][j] = new Elemento(tipoAux, noAux->obterValor()); //Passa os valores para a matriz
            noAux = noAux->obterProx(); //Aponta o n� para o proximo elemento da lista
        }
    }
    noAux->~No(); //Libera mem�ria do n�
    serie->liberar_memoria(); //libera memoria da lista
}

Elemento **aloca_memoria(int lin, int col) //i � a quantidade de linhas e s a quantidade de colunas(que ser� a quantidade de segmentos da nova serie)
{
    Elemento **matriz = (Elemento**) malloc(lin*sizeof(Elemento*));
    for(int k = 0; k < lin; k++)
        matriz[k] = (Elemento*) malloc(col*sizeof(Elemento));

    return matriz;
}

Lista *le_arquivo()
{
    Lista *serie = new Lista(); //cria uma lista auxiliar

    int cont = 1; //Vari�vel auxiliar
    char nome[50]; //Armazena o nome do arquivo que ser� lido
    cout << "DIGITE O NOME DO ARQUIVO: " << endl;
    cin.getline (nome, 50); //L� o nome do arquivo do teclado

    FILE *arq = fopen(nome, "r"); //Abre o arquivo

    float var;  //Variavel auxiliar para leitura do arquivo

    if(arq == NULL) //Caso n�o seja poss�vel abrir o arquivo, � mostrada uma mensagem
    {
        cout << "Nao foi possivel abrir o arquivo" << endl;
        exit(0);
    }
    while(!feof(arq)) //Aqui, � feita a leitura do arquivo e seu armazenamento na lista
    {
        fscanf(arq, "%f,", &var); //primeiramente, � armazenado o valor em uma variavel auxiliar
        serie->inserir_elem(var); //posteriormente, esse valor � inserido na lista
    }//OBSERVA��O: O ULTIMO ELEMENTO DO TXT DEVE SER ";"

    fclose(arq);
    return serie;
}


Elemento **PAA(int s, Elemento *m[][C], int tam) //S ser� a dimens�o da nova s�rie, ou seja, a quantidade de segmentos que ela ter�
{
    Elemento **mAux = aloca_memoria(tam, s); //Cria uma matriz auxiliar

    int cont = 0; //variavel auxiliar
    int e = (C-Descarte)/s; //e � a quantidade de elementos por segmento
    float valueAux = 0;

    if((C-Descarte)%s != 0) //Essa condi��o for�a que todos os segmentos tenham o mesmo tamanho
    {
        cout << "Nao foi possivel realizar o PAA" << endl;
        return 0;  //Se ela n�o puder ser atendida, o PAA n�o � realizado
    }

    for(int i = 0; i < tam; i++)
    {
        int col = 0; //variavel que ir� variar a coluna da nova matriz
        for(int j = Descarte; j < C; j++)
        {
            cont++; //contador para separar cada segmento(usado nas condi��es a seguir)
            if(cont != e)
                valueAux += m[i][j]->getValue(); //enquanto n�o passar por todos os elementos do segmento, vai fazendo o somat�rio deles
            else if(cont == e)
            {
                valueAux += m[i][j]->getValue(); //Antes de fazer a m�dia, deve-se somar um ultimo valor que sobrou
                valueAux = valueAux/e; //feito o somat�rio, � feita ent�o a m�dia
                mAux[i][col].setValue(valueAux); //Armazena o valor transformado em uma nova matriz
                mAux[i][col].setTipo(col);//O r�tulo de cada novo elemento ser� a posi��o da sua coluna
                col++;
                cont = 0;
                valueAux = 0; //zera os valores para uma nova itera��o
            }
        }
    }
    return mAux;
}

float *calculaExtremos(Elemento **mPAA, int tam, int s) //Fun��o que acha o maior e menor elementos em todo o conjunto de dados
{
    float *extremo = (float *) malloc(2 * sizeof(float)); //Vari�vel auxiliar para achar o maior e menor valor do conjunto de dados
    extremo[0] = 50000;
    extremo[1] = -50000;

    for(int i = 0; i < tam; i++)
    {
        for(int j = 0; j < s; j++)
        {
            if(mPAA[i][j].getValue() < extremo[0])
            {
                extremo[0] = mPAA[i][j].getValue();
            }
            if(mPAA[i][j].getValue() > extremo[1])
            {
                extremo[1] = mPAA[i][j].getValue();
            }
        }
    }
    return extremo;
}
void SAX(Elemento **mPAA, int tam, int s, int ordem) //Fun��o que transforma os valores do PAA em s�mbolos
{
    //ordem � a quantidade de s�mbolos que se deseja adicionar
    float *extremo = (float *) malloc(2 * sizeof(float)); //Vari�vel auxiliar para achar o maior e menor valor do conjunto de dados
    extremo = calculaExtremos(mPAA, tam, s); //Calcula os valores extremos

    int quantBreakPoints = (ordem+1); //Breakpoints s�o os valores que separam um s�mbolo do outro
    Elemento *breakPoint = (Elemento *) malloc(quantBreakPoints * sizeof(Elemento)); //Vetor que ir� guardar o valor de cada BreakPoint. Os valores ser�o guardados em ordem crescente, seguindo o crescimento de posi��es do vetor
    char simbolo[26] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'}; //Vetor de S�mbolos

    //Aqui, � setada a faixa de valor entre dois breakpoints
    float intervalo = ( (extremo[1] - extremo[0]) / ordem ); //Faixa de valor de cada intervalo

    //Aqui, � atribuido o valor a cada breakpoint e seu s�mbolo correspondente
    breakPoint[0].setValue(extremo[0]); //Inicializa o primeiro breakpoint com o valor do menor elemento do conjunto de dados
    breakPoint[0].setSimbol(simbolo[0], 0);
    //cout << "VALOR DO BREAKPOINT: " << breakPoint[0].getValue();
    //cout << "   SIMBOLO: " << breakPoint[0].getSimbol(0) << endl;

    for(int i = 1; i < quantBreakPoints; i++)
    {
        if(quantBreakPoints > 26) //S� temos 26 s�mbolos. Essa deve ser a quantidade m�xima de breakpoints
        {
            cout << "ESCOLHA UMA QUANTIDADE DE BREAKPOINTS MENOR QUE 26";
            return;
        }

        breakPoint[i].setValue((breakPoint[i-1].getValue() + intervalo)); //Cada breakpoint ter� uma �rea igual. Para isso, � somada uma quantia linear de valores a cada breakpoint
        if(i != quantBreakPoints-1) //O �ltimo breakpoint n�o ter� nenhum s�mbolo para a �rea acima dele
            breakPoint[i].setSimbol(simbolo[i], 0); //Seta o s�mbolo do breakpoint
        //cout << "VALOR DO BREAKPOINT: " << breakPoint[i].getValue();
        //cout << "   SIMBOLO: " << breakPoint[i].getSimbol(0) << endl;
    }
    cout <<"\n\n\n\n";
//Criando o arquivo que ir� guardar os dados transformados
    ofstream arquivo;
    arquivo.open("SAX.txt", ios::app);
    for(int i = 0; i < tam; i++)
    {
        for(int j = 0; j < s; j++)
        {
            for(int k = 0; k < quantBreakPoints-1; k++) //Analisa em qual faixa de valores o elemento atual est�
            {
                char simb;
                if(mPAA[i][j].getValue() > breakPoint[k].getValue() && mPAA[i][j].getValue() < breakPoint[k+1].getValue()) //Se estiver entre dois breakpoints
                {
                    simb = breakPoint[k].getSimbol(0);
                    mPAA[i][j].setSimbol(simb, 0);
                    break;
                }
                else if(mPAA[i][j].getValue() == breakPoint[k].getValue() && k == 0) //Se o valor estiver em cima do primeiro breakpoint
                {
                    simb = breakPoint[k].getSimbol(0);
                    mPAA[i][j].setSimbol(simb, 0);
                }
                else if(mPAA[i][j].getValue() == breakPoint[k+1].getValue() && ((k+1) == (quantBreakPoints-1)) ) //Se estiver em cima do �ltimo breakpoint
                {
                    simb = breakPoint[k].getSimbol(0);
                    mPAA[i][j].setSimbol(simb, 0);
                }
                else if(mPAA[i][j].getValue() == breakPoint[k].getValue() && k!= 0 && (k+1)!=(quantBreakPoints-1)) //Se estiver em cima de um breakpoint intermedi�rio
                {
                    //Seta ele com o s�mbolo acima do breakpoint
                    simb = breakPoint[k].getSimbol(0);
                    mPAA[i][j].setSimbol(simb, 0);
                }
            }
            //cout << "Valor PAA: " << mPAA[i][j].getValue();
            //cout << "     Simbolo: " << mPAA[i][j].getSimbol(0) << endl;
            //Agora, vamos escrever os s�mbolos no arquivo de dados
            if(j != (s-1))
                arquivo << mPAA[i][j].getSimbol(0) << ","; //Um dado � separado do outro por virgula
            else if(j == (s-1))
                arquivo << mPAA[i][j].getSimbol(0) << "\n"; //Separa��o de uma s�rie e outra

        }
        cout <<"\n";
    }
    arquivo.close();
}
