/*
    Autor do c�digo: Leonardo Vin�cius de Oliveira Toledo - Universidade de S�o Paulo(USP), S�o Carlos - SP
    Email: toledo.leo@usp.br
    Github: https://github.com/LeoToledo
*/
/*
    Ao rodar, digite o nome do arquivo a ser lido(Ex: "arq.csv") e a quantidade de seguimentos e s�mbolos que se deseja na s�rie transformada

    Cada breakpoint ter� uma �rea igual. Para isso, � somada uma quantia linear de valores a cada breakpoint.
    O �ltimo breakpoint n�o ter� nenhum s�mbolo para a �rea acima dele

    obs: A quantidade original de elementos da s�rie deve ser divis�vel pelo n�mero de seguimentos, pois esses seguimentos devem
    ter tamanho igual. Ex: Tamanho original = 12 e quantidade de seguimentos = 2 ou 3 ou 4 ou 6 ou 12

    Caso os dados do arquivo sejam separado por ";" e n�o por "," , altere para ";" na linha 152 de imp.cpp

    A constante "C", definida na linha 4 de tad.h representa a quantidade de elementos por s�rie, incluindo poss�vel �ndices que n�o ser�o
    utilizados nos calculos.
    A constante "DESCARTE", na linha seguinte, representa justamente a quantidade de �ndices por s�rie, para poder descart�-los dos c�lculos.
    Caso n�o hajam �ndices, sete DESCARTE como 0.

    Arquivos com outliers podem prejudicar o funcionamento do c�digo.
*/
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include "tad.h"

using namespace std;

int main(int argc, char *argv[])
{
    Lista *serie = new Lista(); //Cria uma lista que armazenar� todos os dados do arquivo
    serie = le_arquivo(); //Armazena os dados do arquivo na lista "serie"
    int tam = (serie->tamanho()/C); //contador da quantidade de s�ries temporais existentes na lista

//Agora, vamos criar uma matriz[i][j] em que i � a quantidade de s�ries temporais e j � a quantidade de elementos por s�rie
//Essa matriz ser� formada por objetos da classe Elemento
    Elemento *matriz[tam][C];
    aloca_matriz(matriz, serie, tam); //alocando os valores da lista na matriz


//Por fim, vamos realizar o PAA
    cout << "Digite a quantidade de segmentos desejada: ";
    int s; // s � a quantidade de segmentos que a nova s�rie ter�
    cin >> s;

    Elemento **mPAA = aloca_memoria(tam, s); //Matriz que guardar� as s�ries transformadas
    mPAA = PAA(s, matriz, tam); //Faz o c�lculo do PAA

    cout << "Digite a quantidade de Simbolos desejada: ";
    int ordem;
    cin >> ordem;
    SAX(mPAA, tam, s, ordem); //Realiza a convers�o dos valores calculados no PAA para s�mbolos

    return 0;
}
