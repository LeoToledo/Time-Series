#ifndef TAD_H_INCLUDED
#define TAD_H_INCLUDED
#include <iostream>
#define C 14 //quantidade de elementos por s�rie temporal
#define Descarte 2 //Quantidade de elementos que ser�o descartados ao come�o de  cada s�rie(esses elementos geralmente s�o indices)

using namespace std;

//LISTA PARA LER OS ELEMENTOS DA S�RIE TEMPORAL DO TXT

//classe n�
class No //Cada n� � um elemento da s�rie temporal
{
private:
    float v; //vari�vel que guarda o valor do elemento em quest�o
    No* prox; //aponta para o proximo elemento da lista
public:
    No(float v) // construtor
    {
        this->v = v;
        this->prox = 0;
    }
    virtual ~No()
    {
        delete prox;
        delete &v;
    }
    float obterValor() // obt�m o valor
    {
        return v;
    }
    No* obterProx() // obt�m o pr�ximo No
    {
        return prox;
    }
    void setProx(No* p) // seta o pr�ximo No
    {
        prox = p;
    }
};

//classe lista
class Lista
{
private:
    No* cabeca; // primeiro elemento da lista
    No* cauda; // �ltimo elemento da lista
public:
    No *getCabeca()  //Permite acesso ao n� cabe�a
    {
        return cabeca;
    }
    Lista() //construtor
    {
        // se n�o passar elemento, ent�o cabeca e cauda inicializam com NULL
        cabeca = 0;
        cauda = 0;
    }
    Lista(int v) //construtor
    {
        // se passar elemento, ent�o cria novo No
        cabeca = new No(v);
        cauda = cabeca;
    }
    virtual ~Lista() // destrutor
    {
        cout << "TESTE" << endl;
        delete cabeca;
    }
    void mostrar(); //printa na tela os elementos da lista

    bool vazia() // verifica se a lista est� vazia
    {
        return (cabeca == 0);
    }
    void inserir_elem(float v);
    int tamanho(); //Diz o tamanho de uma lista
    void remover(); //Remove um elemento da lista
    void liberar_memoria();//Libera mem�ria de todos os elementos da lista
};

//classe que guarda cada elemento de uma s�rie temporal
class Elemento
{
private:
    int tipo; //Diz o tipo (Lat[0], Long[1], NDVI1[2], NDVI2[3],...,NDVI12[13])
    float value; //Armazena o valor do elemento
    char simbol[2];
public:
    Elemento(int tp, float v) //Construtor
    {
        tipo = tp;
        value = v;
    }
    void setSimbol(char simb, int i)
    {
        simbol[i] = simb;
    }
    void setValue(float valor)
    {
        value = valor;
    }
    void setTipo(float tp)
    {
        tipo = tp;
    }
    float getValue()
    {
        return value;
    }
    char getSimbol(int i)
    {
        return simbol[i];
    }
    int getTipo()
    {
        return tipo;
    }
};



Lista *le_arquivo(); //L� o arquivo dado e aloca seus elementos em uma lista

//Aloca os valores da Lista criada organizados numa matriz
void aloca_matriz(Elemento *m[][C], Lista *serie, int tam); //M � a matriz que guardar� as s�ries, "serie" � a lista com as s�ries a serem distribuidas e tam � a quantidade de s�ries

Elemento **aloca_memoria(int lin, int col); //Aloca mem�ria para uma matriz do tipo Elemento

Elemento **PAA(int s, Elemento *m[][C], int tam); //Realiza o calculo do paa e aloca os novos valores em um arquivo "PAA.txt", na pasta do projeto

float *calculaExtremos(Elemento **mPAA, int tam, int s); //Fun��o que acha o maior e menor elementos em todo o conjunto de dados

void SAX(Elemento **mPAA, int tam, int s, int ordem); //gera um arquivo com os novos valores


#endif // TAD_H_INCLUDED
