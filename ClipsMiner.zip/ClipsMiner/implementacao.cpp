#include "tad.h"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <vector>

using namespace std;

//M�TODOS DA LISTA
void Lista::mostrar() //Mostra os elementos da lista
{
    cout << "\nImprimindo todos os elementos...\n";
    No* c = cabeca;
    if(vazia())
        cout << "A lista nao possui elementos!!\n";
    else
    {
        while(c) // percorre a lista
        {
            cout << c->obterValor() << endl;
            c = c->obterProx();
        }
        cout << endl;
    }
}

void Lista::inserir_elem(float v) //Insere um elemento na lista
{
    No* novo_no = new No(v);
    if(vazia())
    {
        cabeca = novo_no;
        cauda = novo_no;
    }
    else
    {
        cauda->setProx(novo_no);
        cauda = novo_no;
    }
}


int Lista::tamanho()  // retorna o tamanho da lista
{
    if(vazia()) // se for vazia, ent� retorna 0
        return 0;
    No* c = cabeca;
    int tam = 0;

    // percorre a lista
    do
    {
        c = c->obterProx();
        tam++;
    }
    while(c);

    return tam;
}


void Lista::remover() //Remove um elemento da lista
{
    if(!vazia())
    {
        // se houver s� 1 elemento
        if(cabeca->obterProx() == NULL)
            cabeca = NULL;
        else if(cabeca->obterProx()->obterProx() == NULL) // 2 elementos
            cabeca->setProx(NULL);
        else // > 2 elementos
        {
            No* ant_ant = cabeca;
            No* ant = cabeca->obterProx();
            No* corrente = cabeca->obterProx()->obterProx();
            while(corrente)
            {
                No* aux = ant;
                ant = corrente;
                ant_ant = aux;
                corrente = corrente->obterProx();
            }
            delete ant_ant->obterProx(); // libera mem�ria
            ant_ant->setProx(NULL); // seta o prox como NULL
            cauda = ant_ant; // atualiza a cauda
        }
    }
}


void Lista::liberar_memoria()  //libera mem�ria de todos os elementos da lista
{
    No *no = cabeca, *aux;
    while(no != 0)
    {
        aux = no;
        no = no->obterProx();
        free(aux);
    }
    cabeca = 0;
}
//FIM M�TODOS DA LISTA

//ALOCAR VALORES DA LISTA NUMA MATRIZ
void aloca_matriz(Elemento *m[][C], Lista *serie, int tam) //M � a matriz que guardar� as s�ries, "serie" � a lista com as s�ries a serem distribuidas e tam � a quantidade de s�ries
{
    //variaveis auxiliares
    int i, j, tipoAux;
    No *noAux = serie->getCabeca(); //N� auxiliar que ir� percorrer a lista

    for(i = 0; i < tam; i++)
    {
        for(j = 0; j < C; j++)
        {
            tipoAux = j; //guarda o tipo do elemento
            m[i][j] = new Elemento(tipoAux, noAux->obterValor()); //Passa os valores para a matriz
            noAux = noAux->obterProx(); //Aponta o n� para o proximo elemento da lista
        }
    }
    noAux->~No(); //Libera mem�ria do n�
    serie->liberar_memoria(); //libera memoria da lista
}

Elemento **aloca_memoria(int lin, int col) //i � a quantidade de linhas e s a quantidade de colunas(que ser� a quantidade de segmentos da nova serie)
{
    Elemento **matriz = (Elemento**) malloc(lin*sizeof(Elemento*));
    for(int k = 0; k < lin; k++)
        matriz[k] = (Elemento*) malloc(col*sizeof(Elemento));

    return matriz;
}

Lista *le_arquivo()
{
    Lista *serie = new Lista(); //cria uma lista auxiliar

    //int cont = 1; //Vari�vel auxiliar
    char nome[50]; //Armazena o nome do arquivo que ser� lido
    cout << "DIGITE O NOME DO ARQUIVO: " << endl;
    cin.getline (nome, 50); //L� o nome do arquivo do teclado

    FILE *arq = fopen(nome, "r"); //Abre o arquivo

    float var;  //Variavel auxiliar para leitura do arquivo

    if(arq == NULL) //Caso n�o seja poss�vel abrir o arquivo, � mostrada uma mensagem
    {
        cout << "Nao foi possivel abrir o arquivo" << endl;
        exit(0);
    }
    while(!feof(arq)) //Aqui, � feita a leitura do arquivo e seu armazenamento na lista
    {
        fscanf(arq, "%f,", &var); //primeiramente, � armazenado o valor em uma variavel auxiliar
        serie->inserir_elem(var); //posteriormente, esse valor � inserido na lista
    }//OBSERVA��O: O ULTIMO ELEMENTO DO TXT DEVE SER ";"

    fclose(arq);
    return serie;
}


void **ClipsMiner(Elemento *m[][C], int tam, float delta, int lambda, float relFpercentage) //Delta � o valor que define um plat� / Lamda � o comprimento minimo de um plat�
{


    ofstream arquivo; //Cria um arquivo para escrita
    arquivo.open("ClipsMiner.txt", ios::app);

    Elemento **vdiferencas = aloca_memoria(tam, C-Descarte);
    for(int i = 0; i < tam; i++) //Aqui, vamos calcular os elementos do vetor de diferen�as
    {
        for(int j = Descarte; j < (C-1); j++) //Vai at� C-1 pois o vetor de diferen�as, por defini��o, tem um elemento a menos que a s�rie temporal
        {
            //O j come�a no "Descarte" pois os dois primeiros elementos de cada s�rie s�o apenas indices e s�o desconsiderados
            vdiferencas[i][j-Descarte].setValue(m[i][j+1]->getValue() - m[i][j]->getValue());  //Calcula o vetor de diferen�as
            vdiferencas[i][j-Descarte].setPosicao(j); //Armazena a posi��o de inicio de cada elemento do vetor de diferen�as
            vdiferencas[i][j-Descarte].setValorInicio(m[i][j]->getValue()); //Valor do primeiro elemento de cada posi��o do vetor de diferen�as
            vdiferencas[i][j-Descarte].setValorFinal(m[i][j+1]->getValue()); //Valor do �ltimo elemento de cada posi��o do vetor de diferen�as
        }

//Agora, vamos classificar sequ�ncias de Crescimento e Decrescimento
        for(int j = 0; j < C-(Descarte+1); j++)
        {
            if(vdiferencas[i][j].getValue() < 0)  //Se tivermos um crescimento negativo � um ponto de Decrescimento
                vdiferencas[i][j].setOrdemCresc('D');
            if(vdiferencas[i][j].getValue() > 0) //Se for uma varia��o maior ou igual a zero � um evento ascendente
                vdiferencas[i][j].setOrdemCresc('A');
        }

        relevance_factor(m, vdiferencas, tam, relFpercentage, i); //calcula o fator de relev�ncia, que ser� usado posteriormente nos pontos de pico e vale

        int aux1, aux2; //Vari�veis auxiliares para definir pontos de pico e vale
        float relevanceAux1 = 0, relevanceAux2 = 0; //Vari�vel auxiliar para o fator de relev�ncia

        vector < vector<Elemento> > vtransformada; //Aqui � criada uma matriz para guardar os padr�es detectados

        for(int j = 0; j < C-(Descarte+2); j++) //Percorre at� a Penultima posi��o de cada s�rie temporal
        {
            if(vdiferencas[i][j].getordemCresc() == 'A' && vdiferencas[i][j+1].getordemCresc() == 'D') //Se tivermos esse ponto de virada "A-D", temos um ind�cio de pico
            {
                aux1 = j;  //As vari�veis auxiliares ir�o percorrer a s�rie at� encontrar o tamanho total do pico
                aux2 = j+1;
                while(vdiferencas[i][aux1].getordemCresc() == 'A')//percorre para a esquerda encontrando o m�ximo de pontos de ascendencia
                {
                    relevanceAux1 += vdiferencas[i][aux1].getValue();
                    aux1--;
                }
                while(vdiferencas[i][aux2].getordemCresc() == 'D') //percorre para a  direita encontrando o maximo de pontos de descend�ncia
                {
                    relevanceAux2 += vdiferencas[i][aux2].getValue();
                    aux2++;
                }
                relevanceAux2 = relevanceAux2*(-1); //Muda o sinal de relevance, para pegar apenas seu m�dulo

                if(relevanceAux1 >= vdiferencas[i][j].getRelFactor() && relevanceAux2 < vdiferencas[i][j].getRelFactor()) //Caso apenas a parte que decresce n�o passar no teste de fator de relev�ncia
                {
                    for(int k = j+1; k < aux2; k++)
                    {
                        vdiferencas[i][k].setOrdemCresc('A'); //Seta o pequeno decrescimento que n�o foi enquadrado em um pico como "A", para poder concatenar o crescimento anterior com um pr�ximo
                    }
                }
                else if(relevanceAux1 >= vdiferencas[i][j].getRelFactor() && relevanceAux2 >= vdiferencas[i][j].getRelFactor()) //Se as duas sequencias forem maior do que o fator de relevancia, ent�o temos, de fato, um pico
                {
                    int k;
                    vector <Elemento> auxLinha; //Cria uma linha auxiliar vazia para ser adicionada a vtransformada
                    for(k = aux1+1; k < aux2; k++) //Percorre o pico
                    {
                        vdiferencas[i][k].setAuxPosicao(aux1+1);//Seta a posi��o de in�cio do padr�o
                        auxLinha.push_back(vdiferencas[i][k]);
                    }
                    vtransformada.push_back(auxLinha);
                    auxLinha.clear();
                }

                relevanceAux1 = 0; //Volta os fatores auxiliares para zero para poder fazer nova an�lise
                relevanceAux2 = 0;
            }
            else if(vdiferencas[i][j].getordemCresc() == 'D' && vdiferencas[i][j+1].getordemCresc() == 'A') //Se tivermos um ponto de decrescimento e um de crescimento, temos um possivel ponto de vale
            {
                aux1 = j; //As vari�veis auxiliares ir�o percorrer  a s�rie at� encontrar o tamanho total do vale
                aux2 = j+1;
                while(vdiferencas[i][aux1].getordemCresc() == 'D')
                {
                    relevanceAux1 += vdiferencas[i][aux1].getValue(); //Vai somando a amplitude da sequencia no fator de relevancia auxiliar
                    aux1--; //Percorre a sequencia para a esquerda
                }
                relevanceAux1 = relevanceAux1*(-1); //Muda o sinal para pegar apenas o m�dulo
                while(vdiferencas[i][aux2].getordemCresc() == 'A')
                {
                    relevanceAux2 += vdiferencas[i][aux2].getValue(); //Vai somando a amplitude da sequencia no fator de relevancia auxiliar
                    aux2++; //Percorre a sequencia para a direita
                }

                if(relevanceAux1 >= vdiferencas[i][j].getRelFactor() && relevanceAux2 < vdiferencas[i][j].getRelFactor()) //Caso apenas a parte que decresce n�o passar no teste de fator de relev�ncia
                {
                    for(int k = j+1; k < aux2; k++)
                    {
                        vdiferencas[i][k].setOrdemCresc('D'); //Seta o pequeno decrescimento que n�o foi enquadrado em um pico como "D", para poder concatenar o crescimento anterior com um pr�ximo
                    }
                }
                else if(relevanceAux1 >= vdiferencas[i][j].getRelFactor() && relevanceAux2 >= vdiferencas[i][j].getRelFactor()) //Se as duas sequencias forem maior do que o fator de relevancia, ent�o temos, de fato, um pico
                {
                    int k;
                    vector <Elemento> auxLinha; //Cria uma linha auxiliar vazia para ser adicionada a vtransformada
                    for(k = aux1+1; k < aux2; k++) //Percorre o pico
                    {
                        vdiferencas[i][k].setAuxPosicao(aux1+1); //Seta a posi��o de in�cio do padr�o
                        auxLinha.push_back(vdiferencas[i][k]);
                    }
                    vtransformada.push_back(auxLinha);
                    auxLinha.clear();
                }
                relevanceAux1 = 0; //Volta os fatores auxiliares para zero para poder fazer nova an�lise
                relevanceAux2 = 0;
            }
        }

        //Agora, vamos classificar sequ�ncias de plat�
        int lambdaAux = 0;
        for(int j = 0; j < (C-(Descarte+1)); j++)
        {
            if(vdiferencas[i][j].getValue() <= 0) //Procedimento feito para poder analisar o delta em m�dulo e assim determinar se h� um plat�
            {
                delta = delta*(-1); //Passa o delta para seu valor negativo para testar o m�dulo

                if(vdiferencas[i][j].getValue() >= delta)    //Se estiver a uma distancia menor ou igual a delta, temos um ponto de plat�
                {
                    lambdaAux++;
                }
                else if(vdiferencas[i][j].getValue() < delta)
                    lambdaAux = 0;   //Se n�o estiver dentro do delta, quebra-se o ciclo de formar um plat� e zera a contagem
                delta = delta*(-1); //Volta o delta para o valor positivo
            }
            else if(vdiferencas[i][j].getValue() > 0) //Quando o valor for maior que zero
            {
                if(vdiferencas[i][j].getValue() <= delta) //Se estiver entre zero e delta, temos um ponto de plat�
                    lambdaAux++;
                else if(vdiferencas[i][j].getValue() > delta)
                    lambdaAux = 0;        //Se quebrar uma sequencia de plat�, devemos zerar o lambda
            }

            if(lambdaAux >= lambda) //Se o tamanho do plat� for o m�nimo exigido, pode ser definido como um plat� de fato
            {
                if((j) != (C-(Descarte+2))) //Se n�o estiver no �ltimo elemento de uma s�rie
                {
                    if(vdiferencas[i][j+1].getValue() > delta || vdiferencas[i][j+1].getValue() < (delta*(-1))) //Se estiver fora do intervalo de delta
                    {
                        vector <Elemento> auxLinha; //Cria uma linha auxiliar vazia para ser adicionada a vtransformada
                        int k;
                        for(k = (j-lambdaAux+1); k < j+1; k++)
                        {
                            vdiferencas[i][k].setAuxPosicao(j-lambdaAux+1);//Seta a posi��o de in�cio do padr�o
                            auxLinha.push_back(vdiferencas[i][k]);
                        }
                        vtransformada.push_back(auxLinha);
                        auxLinha.clear();

                        lambdaAux = 0;
                    }
                }
                else if( j == (C-(Descarte+2))) //Se estiver no �ltimo elemento da s�rie, faz o for normalmente sem se preocupar se o plat� ainda n�o acabou
                {
                    vector <Elemento> auxLinha; //Cria uma linha auxiliar vazia para ser adicionada a vtransformada
                    int k;
                    for(k = (j-lambdaAux+1); k < j+1; k++)
                    {
                        vdiferencas[i][k].setAuxPosicao(j-lambdaAux+1);//Seta a posi��o de in�cio do padr�o
                        auxLinha.push_back(vdiferencas[i][k]);
                    }
                    vtransformada.push_back(auxLinha);
                    auxLinha.clear();

                    lambdaAux = 0;
                }

            }
        }
        /*
                for(ii = 0; ii < vtransformada.size(); ii++)
        {
            for(jj = 0; jj < vtransformada[ii].size(); jj++)
            {
                if(jj == 0)
                    cout << "POSICAO INICIAL\n" <<"                " << vtransformada[ii][jj].getAuxPosicao() << endl;
                if(jj == (vtransformada[ii].size()-1))
                {
                    cout << vtransformada[ii][jj].getValorInicio() << "  ";
                    cout << vtransformada[ii][jj].getValorFinal() << "\n";
                }
                else
                    cout << vtransformada[ii][jj].getValorInicio() << "  ";
            }
        }
        */
//Agora, vamos ordenar o vector vtransformada baseado na posi��o de in�cio de cada padr�o
        vector < vector<Elemento> > vtransformadaAUX; //Aqui � criada uma matriz para guardar os padr�es detectados ordenados
        int jj, ii;
        int menor = 500, maior = -500;
        int posicao, posMaior;
        for(ii = 0; ii < vtransformada.size(); ii++)
        {
            if(vtransformada[ii][0].getAuxPosicao() > maior)
            {
                maior = vtransformada[ii][0].getAuxPosicao();
                posMaior = ii;
            }
        }
        while(vtransformada[posMaior][0].getAuxPosicao() > 0)
        {
            menor = 500;
            for(ii = 0; ii < vtransformada.size(); ii++)
            {
                if(vtransformada[ii][0].getAuxPosicao() < menor && vtransformada[ii][0].getAuxPosicao() >= 0)
                {
                    menor = vtransformada[ii][0].getAuxPosicao();
                    posicao = ii;
                }
            }
            vtransformadaAUX.push_back(vtransformada[posicao]);
            vtransformada[posicao][0].setAuxPosicao(-1);
        }

        /*
        for(ii = 0; ii < vtransformadaAUX.size(); ii++)
        {
            for(jj = 0; jj < vtransformadaAUX[ii].size(); jj++)
            {
                if(jj == 0)
                    cout << "POSICAO INICIAL\n" <<"                " << vtransformadaAUX[ii][jj].getAuxPosicao() << endl;
                if(jj == (vtransformadaAUX[ii].size()-1))
                {
                    cout << vtransformadaAUX[ii][jj].getValorInicio() << "  ";
                    cout << vtransformadaAUX[ii][jj].getValorFinal() << "\n";
                }
                else
                    cout << vtransformadaAUX[ii][jj].getValorInicio() << "  ";
            }
        }
        */

        for(ii = 0; ii < vtransformadaAUX.size(); ii++)
        {
            for(jj = 0; jj < vtransformadaAUX[ii].size(); jj++)
            {
                if(jj == (vtransformadaAUX[ii].size()-1))
                {
                    arquivo << "(" << vtransformadaAUX[ii][jj].getValorInicio() << ", " << vtransformadaAUX[ii][0].getAuxPosicao() << "),";
                    arquivo << "(" << vtransformadaAUX[ii][jj].getValorFinal() <<", " << vtransformadaAUX[ii][0].getAuxPosicao() << ")";
                }
                else
                    arquivo << "(" << vtransformadaAUX[ii][jj].getValorInicio() << ", " << vtransformadaAUX[ii][0].getAuxPosicao() << "),";
            }
            arquivo <<";";
        }
        arquivo <<"\n";
    }
    arquivo.close();
}
void relevance_factor(Elemento *m[][C], Elemento **vetordif,int tam, float relFpercentage, int i) //Calcula o fator de relev�ncia de uma s�rie temporal
{
    int aux;
    float vmax = -50000, vmin = 50000;

    for(int j = 0; j < C-(Descarte+1); j++)
    {
        if(j == (C-(Descarte+2))) //Se estiver na penultima posi��o do vetor de diferen�as
        {
            aux = vetordif[i][j].getPosicao();
            if(m[i][aux]->getValue() > vmax)  //Se o valor do elemento for maior que vmax, ele passa a ser vmax
                vmax = m[i][aux]->getValue();
            else if(m[i][aux+1]->getValue() > vmax) //Analisa o ultimo elemento da s�rie
                vmax = m[i][aux+1]->getValue();

            if(m[i][aux]->getValue() < vmin) //Se o elemento for menor que vmin, ele passa a ser vmin
                vmin = m[i][aux]->getValue();
            else if(m[i][aux+1]->getValue() < vmin) //Analisa o ultimo elemento da s�rie
                vmin = m[i][aux+1]->getValue();
        }
        //se n�o estiver no final da linha, faz a compara��o normalmente
        aux = vetordif[i][j].getPosicao();
        if(m[i][aux]->getValue() > vmax)  //Se o valor do elemento for maior que vmax, ele passa a ser vmax
            vmax = m[i][aux]->getValue();
        if(m[i][aux]->getValue() < vmin) //Se o elemento for menor que vmin, ele passa a ser vmin
            vmin = m[i][aux]->getValue();
    }
    for(int j = 0; j < C-(Descarte+1); j++)//Feito isso, seta-se o fator de relevancia da s�rie
    {
        vetordif[i][j].setRelFactor((vmax - vmin)*relFpercentage);
    }

}
