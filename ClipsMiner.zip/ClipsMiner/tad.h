#ifndef TAD_H_INCLUDED
#define TAD_H_INCLUDED
#include <iostream>
#define C 14 //quantidade de elementos por s�rie temporal
#define Descarte 0 //Quantidade de elementos a serem desconsiderados em cada s�rie

using namespace std;
//LISTA PARA LER OS ELEMENTOS DA S�RIE TEMPORAL DO TXT
    //classe n�
class No //Cada n� � um elemento da s�rie temporal
{
private:
	float v; //vari�vel que guarda o valor do elemento em quest�o
	No* prox; //aponta para o proximo elemento da lista
public:
	No(float v) // construtor
	{
		this->v = v;
		this->prox = 0;
	}
	virtual ~No()
	{
	    delete prox;
	    delete &v;
	}
 	float obterValor() // obt�m o valor
	{
		return v;
	}
 	No* obterProx() // obt�m o pr�ximo No
	{
		return prox;
	}
 	void setProx(No* p) // seta o pr�ximo No
	{
		prox = p;
	}
};

    //classe lista
class Lista
{
private:
	No* cabeca; // primeiro elemento da lista
	No* cauda; // �ltimo elemento da lista
public:
    No *getCabeca()  //Permite acesso ao n� cabe�a
    {
        return cabeca;
    }
	Lista() //construtor
	{
		// se n�o passar elemento, ent�o cabeca e cauda inicializam com NULL
		cabeca = 0;
		cauda = 0;
	}
	Lista(int v) //construtor
	{
		// se passar elemento, ent�o cria novo No
		cabeca = new No(v);
		cauda = cabeca;
	}
	virtual ~Lista() // destrutor
	{
		delete cabeca;
	}
    void mostrar(); //printa na tela os elementos da lista

    bool vazia() // verifica se a lista est� vazia
	{
		return (cabeca == 0);
	}
	void inserir_elem(float v);
	int tamanho(); //Diz o tamanho de uma lista
	void remover(); //Remove um elemento da lista
	void liberar_memoria();//Libera mem�ria de todos os elementos da lista
};

    //classe que guarda cada elemento de uma s�rie temporal
class Elemento
{
private:
    int posicao; //Posi��o inicial de cada padr�o(pico, plat� ou vale)
    float value; //Armazena o valor do elemento
    char ordemCresc; //Diz se um elemento do vetor diferen�as vai ser Sea, Sed ou Ses
    float relFactor;
    int auxPosicao;
    float valorInicio; //Valor do primeiro elemento de cada posi��o do vetor de diferen�as
    float valorFinal;  //Valor do �ltimo elemento de cada posi��o do vetor de diferen�as
public:
    Elemento(int tp, float v) //Construtor
    {
        posicao = tp;
        value = v;
    }
    void setValorInicio(float vini)
    {
        valorInicio = vini;
    }
    void setValorFinal(float vfim)
    {
        valorFinal = vfim;
    }
    void setAuxPosicao(int auxP)
    {
        auxPosicao = auxP;
    }
    void setRelFactor(float relFact)
    {
        relFactor = relFact;
    }
    void setValue(float valor)
    {
        value = valor;
    }
    void setPosicao(int tp)
    {
        posicao = tp;
    }
    void setOrdemCresc(char ordemcresc)
    {
        ordemCresc = ordemcresc;
    }
    float getRelFactor()
    {
       return relFactor;
    }
    float getValue()
    {
        return value;
    }
    int getTipo()
    {
        return posicao;
    }
    float getValorInicio()
    {
        return valorInicio;
    }
    float getValorFinal()
    {
        return valorFinal;
    }
    char getordemCresc()
    {
        return ordemCresc;
    }
    int getAuxPosicao()
    {
        return auxPosicao;
    }
    int getPosicao()
    {
        return posicao;
    }
};


Lista *le_arquivo(); //L� o arquivo dado e aloca seus elementos em uma lista

    //Aloca os valores da Lista criada organizados numa matriz
void aloca_matriz(Elemento *m[][C], Lista *serie, int tam); //M � a matriz que guardar� as s�ries, "serie" � a lista com as s�ries a serem distribuidas e tam � a quantidade de s�ries

Elemento **aloca_memoria(int lin, int col); //Aloca mem�ria para uma matriz do tipo Elemento

void **ClipsMiner(Elemento *m[][C], int tam, float delta, int lambda, float relFpercentage); //Aplica o m�todo ClipsMiner


void relevance_factor(Elemento *m[][C], Elemento **vetordif, int tam,float relFpercentage, int i); //Calcula o fator de relev�ncia das s�ries temporais. relFpercentage deve ser a porcentagem desejada em decimal
#endif // TAD_H_INCLUDED
