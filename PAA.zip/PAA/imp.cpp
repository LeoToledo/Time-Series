#include "tad.h"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>

using namespace std;

//M�TODOS DA LISTA
void Lista::mostrar() //Implementa��o do m�todo mostrar
{
    cout << "\nImprimindo todos os elementos...\n";
    No* c = cabeca;
    if(vazia())
        cout << "A lista nao possui elementos!!\n";
    else
    {
        while(c) // percorre a lista
        {
            cout << c->obterValor() << endl;
            c = c->obterProx();
        }
        cout << endl;
    }
}

void Lista::inserir_elem(float v)
{
    No* novo_no = new No(v);
    if(vazia())
    {
        cabeca = novo_no;
        cauda = novo_no;
    }
    else
    {
        cauda->setProx(novo_no);
        cauda = novo_no;
    }
}

// retorna o tamanho da lista
int Lista::tamanho()
{
    if(vazia()) // se for vazia, ent� retorna 0
        return 0;
    No* c = cabeca;
    int tam = 0;

    // percorre a lista
    do
    {
        c = c->obterProx();
        tam++;
    }
    while(c);

    return tam;
}


void Lista::remover()
{
    if(!vazia())
    {
        // se houver s� 1 elemento
        if(cabeca->obterProx() == NULL)
            cabeca = NULL;
        else if(cabeca->obterProx()->obterProx() == NULL) // 2 elementos
            cabeca->setProx(NULL);
        else // > 2 elementos
        {
            No* ant_ant = cabeca;
            No* ant = cabeca->obterProx();
            No* corrente = cabeca->obterProx()->obterProx();
            while(corrente)
            {
                No* aux = ant;
                ant = corrente;
                ant_ant = aux;
                corrente = corrente->obterProx();
            }
            delete ant_ant->obterProx(); // libera mem�ria
            ant_ant->setProx(NULL); // seta o prox como NULL
            cauda = ant_ant; // atualiza a cauda
        }
    }
}

void Lista::liberar_memoria()  //libera mem�ria de todos os elementos da lista
{
    No *no = cabeca, *aux;
    while(no != 0)
    {
        aux = no;
        no = no->obterProx();
        free(aux);
    }
    cabeca = 0;
}
//FIM M�TODOS DA LISTA

//ALOCAR VALORES DA LISTA NUMA MATRIZ
void aloca_matriz(Elemento *m[][C], Lista *serie, int tam) //M � a matriz que guardar� as s�ries, "serie" � a lista com as s�ries a serem distribuidas e tam � a quantidade de s�ries
{
    //variaveis auxiliares
    int i, j, tipoAux;
    No *noAux = serie->getCabeca(); //N� auxiliar que ir� percorrer a lista

    for(i = 0; i < tam; i++)
    {
        for(j = 0; j < C; j++)
        {
            tipoAux = j; //guarda o tipo do elemento
            m[i][j] = new Elemento(tipoAux, noAux->obterValor()); //Passa os valores para a matriz
            noAux = noAux->obterProx(); //Aponta o n� para o proximo elemento da lista
        }
    }
    noAux->~No(); //Libera mem�ria do n�
    serie->liberar_memoria(); //libera memoria da lista
}

Elemento **aloca_memoria(int lin, int col) //i � a quantidade de linhas e s a quantidade de colunas(que ser� a quantidade de segmentos da nova serie)
{
    Elemento **matriz = (Elemento**) malloc(lin*sizeof(Elemento*));
    for(int k = 0; k < lin; k++)
        matriz[k] = (Elemento*) malloc(col*sizeof(Elemento));

    return matriz;
}

Lista *le_arquivo()
{
    Lista *serie = new Lista(); //cria uma lista auxiliar

    int cont = 1; //Vari�vel auxiliar
    char nome[50]; //Armazena o nome do arquivo que ser� lido
    cout << "DIGITE O NOME DO ARQUIVO: " << endl;
    cin.getline (nome, 50); //L� o nome do arquivo do teclado

    FILE *arq = fopen(nome, "r"); //Abre o arquivo

    float var;  //Variavel auxiliar para leitura do arquivo

    if(arq == NULL) //Caso n�o seja poss�vel abrir o arquivo, � mostrada uma mensagem
    {
        cout << "Nao foi possivel abrir o arquivo" << endl;
        exit(0);
    }
    while(!feof(arq)) //Aqui, � feita a leitura do arquivo e seu armazenamento na lista
    {
        fscanf(arq, "%f,", &var); //primeiramente, � armazenado o valor em uma variavel auxiliar
        serie->inserir_elem(var); //posteriormente, esse valor � inserido na lista
    }//OBSERVA��O: O ULTIMO ELEMENTO DO TXT DEVE SER ";"

    fclose(arq);
    return serie;
}


Elemento **PAA(int s, Elemento *m[][C], int tam) //S ser� a dimens�o da nova s�rie, ou seja, a quantidade de segmentos que ela ter�
{
    Elemento **mAux = aloca_memoria(tam, s); //Cria uma matriz auxiliar

    int cont = 0; //variavel auxiliar
    int e = (C-DESCARTE)/s; //e � a quantidade de elementos por segmento
    float valueAux = 0;

    if((C-DESCARTE)%s != 0) //Essa condi��o for�a que todos os segmentos tenham o mesmo tamanho
    {
        cout << "Nao foi possivel realizar o PAA" << endl;
        return 0;  //Se ela n�o puder ser atendida, o PAA n�o � realizado
    }

    for(int i = 0; i < tam; i++)
    {
        int col = 0; //variavel que ir� variar a coluna da nova matriz
        for(int j = DESCARTE; j < C; j++)
        {
            cont++; //contador para separar cada segmento(usado nas condi��es a seguir)
            if(cont != e)
                valueAux += m[i][j]->getValue(); //enquanto n�o passar por todos os elementos do segmento, vai fazendo o somat�rio deles
            else if(cont == e)
            {
                valueAux += m[i][j]->getValue(); //Antes de fazer a m�dia, deve-se somar um ultimo valor que sobrou
                valueAux = valueAux/e; //feito o somat�rio, � feita ent�o a m�dia
                mAux[i][col].setValue(valueAux); //Armazena o valor transformado em uma nova matriz
                mAux[i][col].setTipo(col);//O r�tulo de cada novo elemento ser� a posi��o da sua coluna
                col++;
                cont = 0;
                valueAux = 0; //zera os valores para uma nova itera��o
            }
        }
    }

    return mAux;
}


void gera_arquivo(Elemento **mPAA, int tam, int s) //Armazena os dados transformados em um txt
{
    ofstream arquivo;
    arquivo.open("PAA.txt", ios::app);

    for(int i = 0; i < tam; i++)
    {
        for(int j = 0; j < s; j++)
        {
            if(j != (s-1))
                arquivo << mPAA[i][j].getValue() << ","; //Um dado � separado do outro por virgula
            else if(j == (s-1))
                arquivo << mPAA[i][j].getValue() << "\n"; //Separa��o de uma s�rie e outra
        }
    }
    arquivo.close();
}
